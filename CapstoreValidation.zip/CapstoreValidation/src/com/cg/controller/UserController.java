package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cg.domain.CustomerDetails;
import com.cg.domain.Feedback;
import com.cg.domain.JoinOrdersTransaction;
import com.cg.domain.Media;
import com.cg.domain.MediaPath;
import com.cg.domain.Product;
import com.cg.domain.ProductDesc;
import com.cg.domain.ProductDescription;
import com.cg.domain.ProductMedia;
import com.cg.domain.ProductMediaPath;
import com.cg.domain.ProductSold;
import com.cg.domain.ProductWish;
import com.cg.domain.SchemeOffer;
import com.cg.service.ServiceClass;
import org.json.JSONObject;

@Controller
@RequestMapping("/")
public class UserController {

	@Autowired
	public ServiceClass sc;
	/*@RequestMapping(value="AskUserOrMerchant",method=RequestMethod.GET)
	public String ask(){
		return "Ask";
	}
*/
	/*@RequestMapping(value="SignUpUser",method=RequestMethod.GET)
	public String signUpUser(){
		return "UserSignUp";
	}*/
	
	
	
	/*@RequestMapping(value="ChangePwd",method=RequestMethod.GET)
	public String goHome(){
		return "ChangePassword";
	}*/

	@RequestMapping(value="ForgotPwd",method=RequestMethod.GET)
	public String goForgot(){
		return "ForgotPassword";
	}

	@RequestMapping(value="forgot",method=RequestMethod.GET)
	public String forgotData(ModelMap m,@RequestParam("n1") String userid){
		if(userid.startsWith("C_")){
			m.addAttribute("obj", sc.getDetails(userid));
			return "ForgotPasswordUser";
		}
		if(userid.startsWith("M_")){
			m.addAttribute("obj", sc.getDetailsM(userid));
			return "ForgotPasswordMerchant";
		}
		return null;
	}

	/*@RequestMapping(value="forgotM",method=RequestMethod.GET)
	public String forgotDataForM(ModelMap m,@RequestParam("n1") String merchantid){
		m.addAttribute("obj", sc.getDetails(merchantid));
		return "ForgotPasswordMerchant";
	}*/

	@RequestMapping(value="change",method=RequestMethod.GET)	
	public String changePwd(@RequestParam("n1")String userid,@RequestParam("n2")String oldPassword,@RequestParam("n3")String newPassword){
		boolean isChanged=false;
		String x=new String();
		if(userid.startsWith("C_"))			
		{

			isChanged=sc.changePwdService(userid,oldPassword,newPassword);
			
		}

		if(userid.startsWith("M_"))			
		{

			isChanged=sc.changePwdServiceForMerchant(userid, oldPassword, newPassword);
			
		}

		if(isChanged)
		{
			x="Home";
		}
		else
			x="Error";

		return x;
	}


	@RequestMapping(value="submit",method=RequestMethod.GET)
	public String forgotPwd(@RequestParam("n1")String userid,@RequestParam("n2")String secQuestion,@RequestParam("n3")String secAnswer)
	{
		boolean isCorrect=false;
		String x=new String();
		isCorrect=sc.forgotPwd(userid,secQuestion,secAnswer);
		
		if(isCorrect)
			x="Home";
		else
			x="Error";

		return x;

	}

	@RequestMapping(value="submitM",method=RequestMethod.GET)
	public String forgotPwdForMerchant(@RequestParam("n1")String merchantid,@RequestParam("n2")String secQuestion,@RequestParam("n3")String secAnswer)
	{
		boolean isCorrect=false;
		String x=new String();
		isCorrect=sc.forgotPwdForMerchant(merchantid,secQuestion,secAnswer);
		
		if(isCorrect)
			x="Home";
		else
			x="Error";	
		return x;

	}
	


