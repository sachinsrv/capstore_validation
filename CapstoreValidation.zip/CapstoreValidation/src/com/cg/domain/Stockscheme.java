package com.cg.domain;

public class Stockscheme {
		private long stock;

		public long getStock() {
			return stock;
		}

		public void setStock(long stock) {
			this.stock = stock;
		}

		public Stockscheme(long stock) {
			super();
			this.stock = stock;
		}

		
		
}
