package com.cg.service;


import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;

import java.util.Properties;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;






import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;


import com.cg.bankservice.BankWebService;
import com.cg.bankservice.BankWebServiceService;



import com.cg.domain.Merchant;
import com.cg.domain.User;
import com.cg.domain.WishlistCount;

import com.cg.repository.IDaoCategory;
import com.cg.repository.IDaoFeedback;
import com.cg.repository.IDaoMedia;
import com.cg.repository.IDaoMerchant;
import com.cg.repository.IDaoOffer;
import com.cg.repository.IDaoProductDescription;
import com.cg.repository.IDaoReturneditem;
import com.cg.repository.IDaoReturnstatus;
import com.cg.repository.IDaoReward;
import com.cg.repository.IDaoScheme;
import com.cg.repository.IDaoTransaction;
import com.cg.repository.IDaoUser;
import com.cg.repository.IDaoAdvertisement;
import com.cg.repository.IDaoOrder;
import com.cg.repository.IDaoProduct;
import com.cg.repository.IDaoShipping;
import com.cg.repository.IDaoViewcount;
import com.cg.repository.IDaoWishlist;
import com.cg.util.ImageProdId;
import com.cg.util.ProductDescAndImage;
import com.cg.util.Status;

@Service
public class ServiceClass {
	@Value("#{img['ipaddress2']}")	
	String ipaddress;
	@Autowired
	public IDaoAdvertisement idaoadvertisement;
	@Autowired
	public IDaoCategory idaocategory;
	@Autowired
	public IDaoFeedback idaofeedback;
	@Autowired
	public IDaoMedia idaomedia;
	@Autowired
	public IDaoMerchant idaomerchant;
	@Autowired
	public IDaoOffer idaooffer;
	@Autowired
	public IDaoOrder idaoorder;
	@Autowired
	public IDaoProduct idaoproduct;
	@Autowired
	public IDaoProductDescription idaoproductdescription;
	@Autowired
	public IDaoReturneditem idaoreturneditem;
	@Autowired
	public IDaoReturnstatus idaoreturnstatus;
	@Autowired
	public IDaoReward idaoreward;
	@Autowired
	public IDaoScheme idaoscheme;
	@Autowired
	public IDaoShipping idaoshipping;
	@Autowired
	public IDaoTransaction idaotransaction;
	@Autowired
	public IDaoUser idaouser;
	@Autowired
	public IDaoViewcount idaoviewcount;
	@Autowired
	public IDaoWishlist idaowishlist;

	/*final String ALGO = "AES";*/
	/*final byte[] keyValue = new byte[] { 'T', 'h', 'e', 'B', 'e', 's', 't','S', 'e', 'c', 'r','e', 't', 'K', 'e', 'y' };*/	
/*
	@Transactional
	public String encrypt(String Data) throws Exception {

		Key key = generateKey();
		Cipher c = Cipher.getInstance(ALGO);
		c.init(Cipher.ENCRYPT_MODE, key);
		byte[] encVal = c.doFinal(Data.getBytes());
		String encryptedValue = new BASE64Encoder().encode(encVal);
		return encryptedValue;
	}
	@Transactional
	public String decrypt(String encryptedData) throws Exception {
		Key key = generateKey();
		Cipher c = Cipher.getInstance(ALGO);
		c.init(Cipher.DECRYPT_MODE, key);
		byte[] decordedValue = new BASE64Decoder().decodeBuffer(encryptedData);
		byte[] decValue = c.doFinal(decordedValue);
		String decryptedValue = new String(decValue);
		return decryptedValue;
	}

	*/
	//Siddhi's module starts
	@Transactional
	public boolean changePwdService(String userid,String oldPassword, String newPassword) {
		// TODO Auto-generated method stub
		boolean changed=false;
		List<User> userList=new ArrayList<User>();
		userList=idaouser.findAll();

		String password= new String();
		try {
			password = encrypt(oldPassword);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Iterator<User> itr=userList.iterator();
		while(itr.hasNext()){
			User user=new User();
			user=(User)itr.next();
			if(userid.equals(user.getUserId()) && password.equals(user.getUserPassword())){
				String encPassword=new String();
				try {
					encPassword = encrypt(newPassword);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				user.setUserPassword(encPassword);
				idaouser.saveAndFlush(user);
				changed=true;

				break;
			}
		}
		return changed;
	}
	private String encrypt(String oldPassword) {
		// TODO Auto-generated method stub
		return null;
	}
	@Transactional
	public boolean changePwdServiceForMerchant(String merchantid,String oldPassword, String newPassword) {
		// TODO Auto-generated method stub
		boolean changed=false;
		List<Merchant> merchantList=new ArrayList<Merchant>();
		merchantList=idaomerchant.findAll();
		String password= new String();
		try {
			password = encrypt(oldPassword);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Iterator<Merchant> itr=merchantList.iterator();
		while(itr.hasNext()){
			Merchant merchant=new Merchant();
			merchant=(Merchant)itr.next();
			if(merchantid.equals(merchant.getMerchantId()) && password.equals(merchant.getMerchantPassword())){
				String encPassword=new String();
				try {
					encPassword = encrypt(newPassword);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				merchant.setMerchantPassword(encPassword);
				idaomerchant.saveAndFlush(merchant);
				changed=true;
				break;
			}
		}
		return changed;
	}

	@Transactional
	public boolean forgotPwd(String userid, String secQuestion, String secAnswer){
		// TODO Auto-generated method stub

		User u=new User();
		u=idaouser.findOne(userid);
		if(u.getUserSecurityanswer().equals(secAnswer)){
			String pass = null;
			try {
				pass = decrypt(u.getUserPassword());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String receiver=u.getUserEmail();
			String subject="Password recovery from CapStore";
			boolean isSend=emailSender(receiver, subject, pass);
			return true;
		}
		return false;
	}

	private String decrypt(String userPassword) {
		// TODO Auto-generated method stub
		return null;
	}
	@Transactional
	public User getDetails(String userid) {
		return idaouser.findOne(userid);
	}

	@Transactional
	public boolean forgotPwdForMerchant(String userid, String secQuestion, String secAnswer){
		// TODO Auto-generated method stub
		Merchant m=new Merchant();
		m=idaomerchant.findOne(userid);
		if(m.getMerchantSecurityanswer().equals(secAnswer)){
			String pass = null;
			try {
				pass = decrypt(m.getMerchantPassword());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String receiver=m.getMerchantEmail();
			String subject="password recovery";
			boolean isSend=emailSender(receiver, subject, pass);
			return true;
		}
		return false;
	}
	@Transactional
	public Merchant getDetailsM(String userid) {
		return idaomerchant.findOne(userid);
	}
	public boolean emailSender(String toaddress, String subject, String content) {
		String host="nsiore01.capgemini.com";
		final String from="Capstore@capgemini.com";
		final String password=" ";

		Properties propertyobj=new Properties();
		propertyobj.put("mail.smtp.starttls.enable", "true");
		propertyobj.put("mail.smtp.host", host);
		propertyobj.put("mail.smtp.user", from);
		propertyobj.put("mail.smtp.password", password);
		propertyobj.put("mail.smtp.port", "25");
		propertyobj.put("mail.smtp.auth", "true");
		propertyobj.put("mail.debug", "true");
		Session session=Session.getDefaultInstance(propertyobj,
				new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(from,password);
			}
		});
		try	{
			MimeMessage mimemessageobj = new MimeMessage(session);

			mimemessageobj.setFrom(new InternetAddress(from));
			mimemessageobj.setRecipient(Message.RecipientType.TO, new InternetAddress(toaddress));
			mimemessageobj.setSubject(subject);
			mimemessageobj.setText(content);

			Transport transport = session.getTransport("smtp");
			transport.connect(host, from, password);
			
			mimemessageobj.saveChanges();
			Transport.send(mimemessageobj);
			transport.close();
		}	
		catch(Exception exceptionobj)	{
			System.out.println(exceptionobj);
			return false;
		}
		return true;
	}
}
	

