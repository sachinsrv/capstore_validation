package com.cg.domain;

public class Count {
	
	Long countRating;

	public Count(Long countRating) {
		super();
		this.countRating = countRating;
	}

	public Long getCountRating() {
		return countRating;
	}

	public void setCountrating(Long countRating) {
		this.countRating = countRating;
	}
	

}
